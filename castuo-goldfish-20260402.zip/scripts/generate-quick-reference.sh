#!/usr/bin/env bash
set -euo pipefail

OUTPUT="docs/QUICK-REFERENCE.md"
if [[ "${1:-}" == "--output" && -n "${2:-}" ]]; then
  OUTPUT="$2"
fi

mkdir -p "$(dirname "$OUTPUT")"
TODAY="$(date -u +"%Y-%m-%d %H:%M UTC")"
LAST_COMMIT="$(git log -1 --pretty=format:'%h - %s' 2>/dev/null || echo 'N/A')"
OPEN_ISSUES_URL="https://github.com/${GITHUB_REPOSITORY:-Traky12/Castuo-system}/issues"
PR_URL="https://github.com/${GITHUB_REPOSITORY:-Traky12/Castuo-system}/pulls"

cat > "$OUTPUT" <<EOF
# Resumen Visual - CASTUO-SYSTEM 2040

Actualizado: $TODAY
Ultimo cambio: $LAST_COMMIT

## Estado General

| Area | Estado | Detalle |
| --- | --- | --- |
| Seguridad | Verde | MFA, JWT, rate limiting y escaneo de seguridad definidos. |
| Persistencia IoT | Verde | TimescaleDB HA y borrado GDPR ya integrados. |
| TRACES | Amarillo | Cliente y reconciliacion listos, pendiente operacion continua. |
| Vault | Verde | Rotacion de tokens automatizada y despliegue preparado. |
| Observabilidad | Verde | Alertmanager, Prometheus y reglas SLO configuradas. |
| Multi-tenancy | Amarillo | Middleware y arquitectura definidos, rollout gradual pendiente. |
| ISO 27001 | Amarillo | Controles documentados, auditoria pendiente. |

## Checklist Operacional

| Tarea | Estado | Prioridad | Responsable |
| --- | --- | --- | --- |
| SQL Injection prevention | Hecho | P0 | Ingenieria |
| MFA + JWT | Hecho | P0 | Security Team |
| TimescaleDB HA | Hecho | P0 | DevOps |
| GDPR deletion | Hecho | P1 | Compliance |
| Alertmanager SLOs | Hecho | P1 | DevOps |
| Multi-tenancy rollout | En progreso | P1 | Arquitectura |
| ISO 27001 auditoria | En progreso | P2 | Compliance |

## KPIs

| Metrica | Objetivo | Referencia |
| --- | --- | --- |
| Uptime | >= 99.5% | Seguimiento en Grafana/Alertmanager |
| Yield API | >= 99.2% | Validado en Prometheus |
| Latencia P99 | < 500ms | Alarmas configuradas |
| Vulnerabilidades criticas | 0 | Trivy + SARIF |

## Roadmap 30-60-90


action: Seguridad y automatizacion continua - 30 dias

action: Hardening multi-tenant y rollout staging - 60 dias

action: Validacion ISO 27001 y despliegue operativo ampliado - 90 dias

## Enlaces Operativos

- Pull Requests: $PR_URL
- Issues: $OPEN_ISSUES_URL
- Documentacion tecnica: docs/CASTUO-SYSTEM-ANALISIS-COMPLETO.md
- Resumen ejecutivo: docs/RESUMEN-EJECUTIVO-1PAGE.md
EOF

echo "Generated $OUTPUT"
