No hardcoded secrets
