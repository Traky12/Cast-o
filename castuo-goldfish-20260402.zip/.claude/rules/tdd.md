pytest first → code second
