"""
SABIONDA — Registro de eventos en GaiaChain (blockchain)

Endpoint:
  - POST /api/v1/blockchain/log → Registra un evento en GaiaChain
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/blockchain", tags=["blockchain"])


# ─── Modelos ──────────────────────────────────────────────────────────────────

class BlockchainLogRequest(BaseModel):
    event_type: str = Field(..., min_length=1, description="Tipo de evento (ej: code_update)")
    data: dict[str, Any] = Field(default_factory=dict, description="Datos asociados al evento")
    actor: str = Field(..., min_length=1, description="Identificador del actor que genera el evento")


class BlockchainLogResponse(BaseModel):
    txid: str
    event_type: str
    actor: str
    timestamp: str


# ─── Endpoint ─────────────────────────────────────────────────────────────────

@router.post("/log", response_model=BlockchainLogResponse)
async def log_to_blockchain(request: BlockchainLogRequest) -> BlockchainLogResponse:
    """
    Registra un evento en GaiaChain para trazabilidad inmutable.

    Devuelve el txid de la transacción blockchain.
    Devuelve 503 si GaiaChain no está disponible.
    """
    try:
        from castuo_graph.blockchain.gaiachain import GaiachainConnector  # noqa: PLC0415

        connector = GaiachainConnector()
        timestamp = datetime.now(timezone.utc).isoformat()

        payload: dict[str, Any] = {
            "event_type": request.event_type,
            "data": request.data,
            "actor": request.actor,
            "timestamp": timestamp,
        }

        txid = connector.register_hash(payload)

        logger.info(
            "GaiaChain log: event=%s actor=%s txid=%s",
            request.event_type,
            request.actor,
            txid,
        )

        return BlockchainLogResponse(
            txid=txid,
            event_type=request.event_type,
            actor=request.actor,
            timestamp=timestamp,
        )

    except Exception as exc:
        logger.error("Error registrando en GaiaChain: %s", exc)
        raise HTTPException(status_code=503, detail=f"Error de blockchain: {exc}")
