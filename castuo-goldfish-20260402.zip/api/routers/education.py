from __future__ import annotations

from typing import Any

from fastapi import APIRouter
from pydantic import BaseModel, Field

try:
    from metrics.prometheus import record_active_users, record_lesson_view
    from services.education_content_validator import validator
except ModuleNotFoundError:  # pragma: no cover
    from api.metrics.prometheus import record_active_users, record_lesson_view
    from api.services.education_content_validator import validator


router = APIRouter(prefix="/api/v1/education", tags=["Education"])


class EducationContentRequest(BaseModel):
    text: str = Field(..., min_length=1)
    audience: str = Field(default="5-12")
    topic: str = Field(default="general")
    images: list[dict[str, Any]] = Field(default_factory=list)
    activities: list[dict[str, Any]] = Field(default_factory=list)


class LessonViewRequest(BaseModel):
    age_group: str
    topic: str


class ActiveUsersRequest(BaseModel):
    region: str
    count: int = Field(..., ge=0)


@router.post("/validate")
async def validate_education_content(payload: EducationContentRequest) -> dict[str, Any]:
    content = payload.model_dump()
    valid, issues = validator.validate(content)
    return {
        "status": "OK",
        "valid": valid,
        "issues": issues,
        "audit": validator.build_audit_payload(content),
    }


@router.get("/example-content")
async def example_content() -> dict[str, Any]:
    return {
        "text": "En esta leccion aprenderemos como las plantas necesitan agua y luz para crecer. Todos podemos contribuir a cuidar el medio ambiente desde la igualdad y la cooperacion.",
        "audience": "5-12",
        "topic": "huertos escolares",
        "images": [
            {
                "url": "/images/planta.jpg",
                "alt": "Ilustracion de una planta creciendo en un huerto escolar con ninos de diferentes origenes trabajando juntos.",
            }
        ],
        "activities": [
            {
                "type": "juego",
                "description": "Arrastra gotas de agua a las plantas para mantener la humedad adecuada.",
                "accessibility": {
                    "keyboard_nav": True,
                    "screen_reader_text": "Juego: Riega la planta. Usa las flechas para moverte y la barra espaciadora para regar.",
                },
            }
        ],
    }


@router.post("/lesson-view")
async def register_lesson_view(payload: LessonViewRequest) -> dict[str, Any]:
    record_lesson_view(payload.age_group, payload.topic)
    return {"status": "OK", "tracked": True}


@router.post("/active-users")
async def register_active_users(payload: ActiveUsersRequest) -> dict[str, Any]:
    record_active_users(payload.region, payload.count)
    return {"status": "OK", "tracked": True}
