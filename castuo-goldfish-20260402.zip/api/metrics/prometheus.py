"""
Métricas de negocio Prometheus para CASTÚO-SYSTEM™.

Expone /metrics con métricas de lotes, IoT, blockchain, documentos y latencia.
"""

import time

from fastapi import Request, Response

try:
    from prometheus_client import (
        CONTENT_TYPE_LATEST,
        Counter,
        Gauge,
        Histogram,
        REGISTRY,
        generate_latest,
    )

    _PROMETHEUS_AVAILABLE = True
except ImportError:  # pragma: no cover
    _PROMETHEUS_AVAILABLE = False

# ------------------------------------------------------------------
# Definición de métricas (sólo si prometheus_client está instalado)
# ------------------------------------------------------------------


def _get_or_create_metric(factory, name: str, documentation: str, labelnames: list[str] | None = None):
    if not _PROMETHEUS_AVAILABLE:  # pragma: no cover
        return None

    existing = REGISTRY._names_to_collectors.get(name)  # type: ignore[attr-defined]
    if existing is not None:
        return existing

    labels = labelnames or []
    return factory(name, documentation, labels)

if _PROMETHEUS_AVAILABLE:
    LOTES_PROCESADOS = _get_or_create_metric(
        Counter,
        "castuo_lotes_procesados_total",
        "Total de lotes procesados",
        ["tenant", "status"],
    )
    IOT_REQUESTS = _get_or_create_metric(
        Counter,
        "castuo_iot_requests_total",
        "Requests IoT recibidos",
        ["tenant", "device_id"],
    )
    BLOCKCHAIN_TX = _get_or_create_metric(
        Counter,
        "castuo_blockchain_tx_total",
        "Transacciones en blockchain",
        ["tenant", "chain", "status"],
    )
    DOCUMENTOS_GENERADOS = _get_or_create_metric(
        Counter,
        "castuo_documentos_generados_total",
        "Documentos generados (PDF/QR)",
        ["tenant", "type", "signed"],
    )
    LATENCIA_ENDPOINT = _get_or_create_metric(
        Histogram,
        "castuo_endpoint_latency_seconds",
        "Latencia de endpoints (segundos)",
        ["tenant", "endpoint", "status_code"],
    )
    SYSTEM_MEMORY_USAGE = _get_or_create_metric(
        Gauge,
        "castuo_system_memory_usage_bytes",
        "Uso de memoria del sistema",
    )
    LESSON_VIEWS = _get_or_create_metric(
        Counter,
        "lesson_views_total",
        "Total de lecciones vistas",
        ["age_group", "topic"],
    )
    USER_LOGINS = _get_or_create_metric(
        Gauge,
        "active_users",
        "Usuarios activos por region",
        ["region"],
    )
else:  # pragma: no cover — stub cuando prometheus no está instalado

    class _NoopCounter:  # type: ignore[no-redef]
        def labels(self, *a, **kw):
            return self

        def inc(self, *a, **kw):
            pass

    class _NoopHistogram(_NoopCounter):  # type: ignore[no-redef]
        def observe(self, *a, **kw):
            pass

    class _NoopGauge(_NoopCounter):  # type: ignore[no-redef]
        def set(self, *a, **kw):
            pass

    LOTES_PROCESADOS = _NoopCounter()
    IOT_REQUESTS = _NoopCounter()
    BLOCKCHAIN_TX = _NoopCounter()
    DOCUMENTOS_GENERADOS = _NoopCounter()
    LATENCIA_ENDPOINT = _NoopHistogram()
    SYSTEM_MEMORY_USAGE = _NoopGauge()
    LESSON_VIEWS = _NoopCounter()
    USER_LOGINS = _NoopGauge()


# ------------------------------------------------------------------
# Setup
# ------------------------------------------------------------------


def setup_metrics(app) -> None:
    """Registra el endpoint /metrics y el middleware de latencia en la app."""

    if _PROMETHEUS_AVAILABLE:

        @app.get("/metrics", include_in_schema=False)
        async def metrics_endpoint():
            return Response(
                content=generate_latest(),
                media_type=CONTENT_TYPE_LATEST,
            )

        @app.middleware("http")
        async def monitor_latency(request: Request, call_next):
            start = time.time()
            response = await call_next(request)
            latency = time.time() - start
            tenant = request.headers.get("X-Tenant-Id", "default")
            LATENCIA_ENDPOINT.labels(
                tenant, request.url.path, str(response.status_code)
            ).observe(latency)
            return response


def record_lesson_view(age_group: str, topic: str) -> None:
    LESSON_VIEWS.labels(age_group, topic).inc()


def record_active_users(region: str, count: int) -> None:
    USER_LOGINS.labels(region).set(count)
