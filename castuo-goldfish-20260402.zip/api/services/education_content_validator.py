from __future__ import annotations

import hashlib
import json
from typing import Any


class EducationalContentValidator:
    """Validador ético y de accesibilidad para recursos educativos."""

    def __init__(self) -> None:
        self.banned_words = self._load_banned_words()
        self.required_topics_by_age: dict[str, list[str]] = {
            "5-12": ["igualdad", "medio ambiente", "cooperacion"],
            "13-16": ["sostenibilidad", "tecnologia inclusiva", "derechos laborales"],
            "17+": ["etica en ia", "agricultura regenerativa", "derechos humanos"],
        }

    def validate(self, content: dict[str, Any]) -> tuple[bool, list[str]]:
        issues: list[str] = []
        text = str(content.get("text", "")).lower()

        for word in self.banned_words:
            if word in text:
                issues.append(f"Contiene termino prohibido: {word}")

        age_group = str(content.get("audience", "5-12"))
        required_topics = self.required_topics_by_age.get(age_group, [])
        for topic in required_topics:
            if topic not in text:
                issues.append(f"Falta tema requerido para {age_group}: {topic}")

        for img in content.get("images", []):
            if not isinstance(img, dict) or not str(img.get("alt", "")).strip():
                issues.append("Imagen sin descripcion alternativa accesible")

        for activity in content.get("activities", []):
            accessibility = activity.get("accessibility", {}) if isinstance(activity, dict) else {}
            if not accessibility.get("screen_reader_text"):
                issues.append("Actividad sin screen_reader_text")

        return (len(issues) == 0, issues)

    def build_audit_payload(self, content: dict[str, Any]) -> dict[str, Any]:
        normalized = json.dumps(content, sort_keys=True, ensure_ascii=False)
        return {
            "content_hash": hashlib.sha256(normalized.encode("utf-8")).hexdigest(),
            "audience": content.get("audience", "5-12"),
            "topic": content.get("topic", "general"),
            "ready_for_gaiachain": True,
        }

    def _load_banned_words(self) -> list[str]:
        return [
            "discriminacion",
            "exclusion",
            "violencia",
            "quimicos toxicos",
            "trabajo infantil",
            "deforestacion ilegal",
        ]


validator = EducationalContentValidator()
